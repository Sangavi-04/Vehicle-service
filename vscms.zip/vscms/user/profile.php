<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$message = "";

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_profile"])) {
    $name = trim($_POST["name"]);
    $phone = trim($_POST["phone"]);
    
    $sql = "UPDATE customers SET name = :name, phone = :phone WHERE id = :id";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":phone", $phone, PDO::PARAM_STR);
        $stmt->bindParam(":id", $user_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $_SESSION["user_name"] = $name;
            $message = "Profile updated successfully!";
        }
        unset($stmt);
    }
}

// Handle vehicle addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_vehicle"])) {
    $make = trim($_POST["make"]);
    $model = trim($_POST["model"]);
    $year = trim($_POST["year"]);
    $plate = trim($_POST["plate"]);
    
    // Check if plate number already exists
    $check_sql = "SELECT id FROM vehicles WHERE plate = :plate";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bindParam(":plate", $plate, PDO::PARAM_STR);
    $check_stmt->execute();
    
    if ($check_stmt->rowCount() > 0) {
        $message = "Error: A vehicle with this license plate number already exists.";
    } else {
        // Insert new vehicle
        $sql = "INSERT INTO vehicles (customer_id, make, model, plate, year) 
                VALUES (:customer_id, :make, :model, :plate, :year)";
        
        if($stmt = $conn->prepare($sql)){
            $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
            $stmt->bindParam(":make", $make, PDO::PARAM_STR);
            $stmt->bindParam(":model", $model, PDO::PARAM_STR);
            $stmt->bindParam(":plate", $plate, PDO::PARAM_STR);
            $stmt->bindParam(":year", $year, PDO::PARAM_STR);
            
            if($stmt->execute()){
                $message = "Vehicle added successfully!";
            } else {
                $message = "Error adding vehicle. Please try again.";
            }
        }
    }
}

// Get user details
$sql = "SELECT name, email, phone FROM customers WHERE id = :id";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bindParam(":id", $user_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }
    unset($stmt);
}

// Get user's vehicles
$sql = "SELECT * FROM vehicles WHERE customer_id = :customer_id ORDER BY make, model";
$vehicles = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .vehicle-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .vehicle-table th, .vehicle-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .vehicle-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .vehicle-table tr:hover {
            background-color: #f5f5f5;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="user_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert <?php echo strpos($message, 'Error') !== false ? 'alert-error' : 'alert-success'; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <h2>Personal Information</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="update_profile" class="btn" value="Update Profile">
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Add New Vehicle</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label>Make</label>
                        <input type="text" name="make" required>
                    </div>
                    <div class="form-group">
                        <label>Model</label>
                        <input type="text" name="model" required>
                    </div>
                    <div class="form-group">
                        <label>License Plate</label>
                        <input type="text" name="plate" required>
                    </div>
                    <div class="form-group">
                        <label>Year</label>
                        <input type="text" name="year" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="add_vehicle" class="btn" value="Add Vehicle">
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Your Vehicles</h2>
                <?php if (empty($vehicles)): ?>
                    <p>No vehicles registered yet.</p>
                <?php else: ?>
                    <table class="vehicle-table">
                        <thead>
                            <tr>
                                <th>Make</th>
                                <th>Model</th>
                                <th>License Plate</th>
                                <th>Year</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vehicles as $vehicle): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($vehicle['make']); ?></td>
                                    <td><?php echo htmlspecialchars($vehicle['model']); ?></td>
                                    <td><?php echo htmlspecialchars($vehicle['plate']); ?></td>
                                    <td><?php echo htmlspecialchars($vehicle['year']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 