<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

// Get user ID from URL
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($user_id <= 0) {
    header("location: manage_users.php");
    exit;
}

// Get user details
$sql = "SELECT * FROM customers WHERE id = :id";
$user = null;
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":id", $user_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if(!$user) {
    header("location: manage_users.php");
    exit;
}

// Get user's vehicles
$sql = "SELECT * FROM vehicles WHERE customer_id = :customer_id ORDER BY id DESC";
$vehicles = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Get user's services
$sql = "SELECT s.*, v.make, v.model, v.plate, m.name as mechanic_name 
        FROM services s 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        INNER JOIN mechanics m ON s.mechanic_id = m.id 
        WHERE s.customer_id = :customer_id 
        ORDER BY s.service_date DESC";
$services = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Customer - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .user-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .info-item h3 {
            margin: 0 0 10px 0;
            color: var(--primary-color);
        }
        .info-item p {
            margin: 0;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-pending { background-color: #f1c40f; }
        .badge-in-progress { background-color: #3498db; }
        .badge-completed { background-color: #2ecc71; }
        .badge-cancelled { background-color: #e74c3c; }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="manage_users.php" class="btn">Back to Customers</a>
            </div>

            <div class="card">
                <h2>Customer Details</h2>
                <div class="user-info">
                    <div class="info-item">
                        <h3>Personal Information</h3>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name'] ?? 'Not provided'); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email'] ?? 'Not provided'); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone'] ?? 'Not provided'); ?></p>
                        <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address'] ?? 'Not provided'); ?></p>
                    </div>
                    <div class="info-item">
                        <h3>Account Information</h3>
                        <p><strong>Member Since:</strong> <?php echo isset($user['created_at']) ? date('F j, Y', strtotime($user['created_at'])) : 'Not available'; ?></p>
                        <p><strong>Last Login:</strong> <?php echo isset($user['last_login']) ? date('F j, Y g:i A', strtotime($user['last_login'])) : 'Not available'; ?></p>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2>Vehicles</h2>
                <?php if (empty($vehicles)): ?>
                    <p>No vehicles registered.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Make</th>
                                    <th>Model</th>
                                    <th>Year</th>
                                    <th>Plate</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($vehicles as $vehicle): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($vehicle['make'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['model'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['year'] ?? 'N/A'); ?></td>
                                        <td><?php echo htmlspecialchars($vehicle['plate'] ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card">
                <h2>Service History</h2>
                <?php if (empty($services)): ?>
                    <p>No service history found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Vehicle</th>
                                    <th>Mechanic</th>
                                    <th>Status</th>
                                    <th>Payment Status</th>
                                    <th>Amount</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $service): ?>
                                    <tr>
                                        <td><?php echo isset($service['service_date']) ? date('F j, Y g:i A', strtotime($service['service_date'])) : 'N/A'; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars(($service['make'] ?? '') . " " . ($service['model'] ?? '')); ?><br>
                                            <small>Plate: <?php echo htmlspecialchars($service['plate'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['mechanic_name'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo isset($service['status']) ? str_replace('_', '-', $service['status']) : 'pending'; ?>">
                                                <?php echo isset($service['status']) ? ucfirst(str_replace('_', ' ', $service['status'])) : 'Pending'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo ($service['payment_status'] ?? '') == 'paid' ? 'completed' : 'pending'; ?>">
                                                <?php echo ucfirst($service['payment_status'] ?? 'pending'); ?>
                                            </span>
                                        </td>
                                        <td>$<?php echo isset($service['amount']) ? number_format($service['amount'], 2) : '0.00'; ?></td>
                                        <td><?php echo htmlspecialchars($service['notes'] ?? 'No notes'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 