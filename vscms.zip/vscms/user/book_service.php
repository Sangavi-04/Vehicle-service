<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$message = "";

// Get user's vehicles
$sql = "SELECT * FROM vehicles WHERE customer_id = :id";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bindParam(":id", $user_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    unset($stmt);
}

// Handle service booking
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vehicle_id = trim($_POST["vehicle_id"]);
    $service_date = trim($_POST["service_date"]);
    $service_time = trim($_POST["service_time"]);
    $notes = trim($_POST["notes"]);
    
    $datetime = $service_date . " " . $service_time;
    
    $sql = "INSERT INTO services (customer_id, vehicle_id, service_date, notes) VALUES (:customer_id, :vehicle_id, :service_date, :notes)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
        $stmt->bindParam(":vehicle_id", $vehicle_id, PDO::PARAM_INT);
        $stmt->bindParam(":service_date", $datetime, PDO::PARAM_STR);
        $stmt->bindParam(":notes", $notes, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            $message = "Service booked successfully!";
        }
        unset($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Service - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="user_dashboard.php" class="btn">Back to Dashboard</a>
            </div>
            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="card">
                <h2>Schedule a Service</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label>Select Vehicle</label>
                        <select name="vehicle_id" required>
                            <option value="">Choose a vehicle</option>
                            <?php foreach ($vehicles as $vehicle): ?>
                                <option value="<?php echo $vehicle['id']; ?>">
                                    <?php echo htmlspecialchars($vehicle['make'] . " " . $vehicle['model'] . " (" . $vehicle['plate'] . ")"); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Service Date</label>
                        <input type="date" name="service_date" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label>Service Time</label>
                        <input type="time" name="service_time" required min="09:00" max="17:00">
                    </div>
                    <div class="form-group">
                        <label>Service Notes</label>
                        <textarea name="notes" rows="4" placeholder="Describe the service needed..."></textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn" value="Book Service">
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html> 