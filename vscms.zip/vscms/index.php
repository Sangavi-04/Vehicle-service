<?php
require_once 'includes/db_connection.php';

// Check if user is already logged in
if(isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true){
    header("location: user/user_dashboard.php");
    exit;
}

if(isset($_SESSION["admin_loggedin"]) && $_SESSION["admin_loggedin"] === true){
    header("location: admin/admin_dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicle Service Center Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        .welcome-text {
            text-align: center;
            margin-bottom: 40px;
            color: var(--primary-color);
            font-size: 2.5em;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        .login-container {
            display: flex;
            gap: 30px;
            justify-content: center;
            align-items: center;
        }
        .login-box {
            width: 300px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            border: 1px solid rgba(255, 255, 255, 0.18);
            transition: transform 0.3s ease;
        }
        .login-box:hover {
            transform: translateY(-10px);
        }
        .login-box h3 {
            color: var(--primary-color);
            margin-bottom: 20px;
            font-size: 1.5em;
        }
        .login-box .btn {
            width: 80%;
            padding: 12px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .login-box .btn:hover {
            background: var(--primary-color-dark);
            transform: scale(1.05);
        }
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }
            .welcome-text {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="welcome-text">Welcome to Vehicle Service Center Management System</h1>
        <div class="login-container">
            <div class="login-box">
                <h3>User Login</h3>
                <a href="user/user_login.php" class="btn">Login as User</a>
            </div>
            <div class="login-box">
                <h3>Admin Login</h3>
                <a href="admin/admin_login.php" class="btn">Login as Admin</a>
            </div>
        </div>
    </div>
</body>
</html> 