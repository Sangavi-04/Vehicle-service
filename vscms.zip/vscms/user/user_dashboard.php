<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="logout.php" class="btn" style="background: #d32f2f;">Logout</a>
            </div>
            <div class="dashboard">
                <div class="card">
                    <h3>Profile</h3>
                    <p>View and update personal and vehicle information</p>
                    <a href="profile.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Book Service</h3>
                    <p>Schedule a new service appointment</p>
                    <a href="book_service.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Track Progress</h3>
                    <p>Monitor current service status</p>
                    <a href="track_progress.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Service History</h3>
                    <p>View previous service records</p>
                    <a href="service_history.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Payments</h3>
                    <p>Make payments and view payment history</p>
                    <div class="btn-group">
                        <a href="make_payment.php" class="btn">Pay Now</a>
                        <a href="payment_history.php" class="btn" style="background: var(--secondary-color);">History</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 