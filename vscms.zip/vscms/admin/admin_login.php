<?php
require_once '../includes/db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    
    // Validate credentials (in a real system, you'd have an admin table)
    if ($email === "admin@vscms.com" && $password === "admin123") {
        $_SESSION["admin_loggedin"] = true;
        header("location: admin_dashboard.php");
        exit;
    } else {
        $login_err = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <div class="login-container">
            <h2>Enter Admin Credentials</h2>
            <?php 
            if(!empty($login_err)){
                echo '<div style="color: red; margin-bottom: 15px;">' . $login_err . '</div>';
            }        
            ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" required>
                </div>    
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" required>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn" value="Login">
                </div>
            </form>
            <p style="text-align: center; margin-top: 20px;">
                <a href="../index.php" class="btn">Back to Home</a>
            </p>
        </div>
    </div>
</body>
</html> 