<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

$message = "";

// Handle amount update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_amount"])) {
    $service_id = trim($_POST["service_id"]);
    $amount = trim($_POST["amount"]);
    
    try {
        $sql = "UPDATE services SET amount = :amount WHERE id = :service_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":amount", $amount, PDO::PARAM_STR);
        $stmt->bindParam(":service_id", $service_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $message = "Service amount updated successfully!";
        } else {
            $message = "Error updating amount. Please try again.";
        }
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Get all services
$sql = "SELECT s.*, c.name as customer_name, v.make, v.model, v.plate 
        FROM services s 
        INNER JOIN customers c ON s.customer_id = c.id 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        ORDER BY s.service_date DESC";
$services = [];
if($stmt = $conn->prepare($sql)){
    if($stmt->execute()){
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Calculate total revenue
$total_revenue = 0;
foreach ($services as $service) {
    if ($service['payment_status'] === 'paid') {
        $total_revenue += $service['amount'];
    }
}

// Calculate pending payments
$pending_amount = 0;
foreach ($services as $service) {
    if ($service['payment_status'] === 'pending') {
        $pending_amount += $service['amount'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Amounts - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .stats-card {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }
        .stat-item h3 {
            margin: 0 0 10px 0;
            color: var(--primary-color);
        }
        .stat-item p {
            margin: 0;
            font-size: 1.5em;
            font-weight: bold;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input {
            width: 120px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-paid {
            background-color: #2ecc71;
        }
        .badge-pending {
            background-color: #f1c40f;
        }
        .amount-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="stats-card">
                <div class="stat-item">
                    <h3>Total Revenue</h3>
                    <p>$<?php echo number_format($total_revenue, 2); ?></p>
                </div>
                <div class="stat-item">
                    <h3>Pending Payments</h3>
                    <p>$<?php echo number_format($pending_amount, 2); ?></p>
                </div>
            </div>

            <div class="card">
                <h2>Service Amounts</h2>
                <?php if (empty($services)): ?>
                    <p>No services found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Customer</th>
                                    <th>Vehicle</th>
                                    <th>Service Type</th>
                                    <th>Amount</th>
                                    <th>Payment Status</th>
                                    <th>Update Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $service): ?>
                                    <tr>
                                        <td><?php echo isset($service['service_date']) ? date('F j, Y g:i A', strtotime($service['service_date'])) : 'N/A'; ?></td>
                                        <td><?php echo htmlspecialchars($service['customer_name']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars(($service['make'] ?? '') . " " . ($service['model'] ?? '')); ?><br>
                                            <small>Plate: <?php echo htmlspecialchars($service['plate'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['service_type'] ?? 'N/A'); ?></td>
                                        <td>$<?php echo isset($service['amount']) ? number_format($service['amount'], 2) : '0.00'; ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $service['payment_status']; ?>">
                                                <?php echo ucfirst($service['payment_status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="amount-form">
                                                <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                <div class="form-group">
                                                    <input type="number" name="amount" value="<?php echo $service['amount']; ?>" step="0.01" min="0" required>
                                                </div>
                                                <input type="submit" name="update_amount" class="btn" value="Update">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 