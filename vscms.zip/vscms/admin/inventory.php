<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

$message = "";

// Handle item addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_item"])) {
    $item_name = trim($_POST["item_name"]);
    $quantity = trim($_POST["quantity"]);
    $cost = trim($_POST["cost"]);
    
    $sql = "INSERT INTO inventory (item_name, quantity, cost) VALUES (:item_name, :quantity, :cost)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":item_name", $item_name, PDO::PARAM_STR);
        $stmt->bindParam(":quantity", $quantity, PDO::PARAM_INT);
        $stmt->bindParam(":cost", $cost, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            $message = "Item added successfully!";
        }
    }
}

// Handle item update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_item"])) {
    $item_id = $_POST["item_id"];
    $quantity = trim($_POST["quantity"]);
    $cost = trim($_POST["cost"]);
    
    $sql = "UPDATE inventory SET quantity = :quantity, cost = :cost WHERE id = :id";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":quantity", $quantity, PDO::PARAM_INT);
        $stmt->bindParam(":cost", $cost, PDO::PARAM_STR);
        $stmt->bindParam(":id", $item_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $message = "Item updated successfully!";
        }
    }
}

// Get all inventory items
$sql = "SELECT * FROM inventory ORDER BY item_name";
$inventory = [];
if($stmt = $conn->prepare($sql)){
    if($stmt->execute()){
        $inventory = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Management - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .inventory-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .inventory-table th, .inventory-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .inventory-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .inventory-table tr:hover {
            background-color: #f5f5f5;
        }
        .low-stock {
            color: #e74c3c;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="card">
                <h2>Add New Item</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label>Item Name</label>
                        <input type="text" name="item_name" required>
                    </div>
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" name="quantity" required min="0">
                    </div>
                    <div class="form-group">
                        <label>Cost (per unit)</label>
                        <input type="number" name="cost" required min="0" step="0.01">
                    </div>
                    <div class="form-group">
                        <input type="submit" name="add_item" class="btn" value="Add Item">
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Current Inventory</h2>
                <?php if (empty($inventory)): ?>
                    <p>No items found in inventory.</p>
                <?php else: ?>
                    <table class="inventory-table">
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Quantity</th>
                                <th>Cost (per unit)</th>
                                <th>Last Updated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($inventory as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                                    <td class="<?php echo $item['quantity'] < 10 ? 'low-stock' : ''; ?>">
                                        <?php echo $item['quantity']; ?>
                                    </td>
                                    <td>$<?php echo number_format($item['cost'], 2); ?></td>
                                    <td><?php echo date('F j, Y g:i A', strtotime($item['last_updated'])); ?></td>
                                    <td>
                                        <button onclick="showUpdateForm(<?php echo $item['id']; ?>)" class="btn">Update</button>
                                    </td>
                                </tr>
                                <tr id="update-form-<?php echo $item['id']; ?>" style="display: none;">
                                    <td colspan="5">
                                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                                            <input type="hidden" name="item_id" value="<?php echo $item['id']; ?>">
                                            <div class="form-group">
                                                <label>Quantity</label>
                                                <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" required min="0">
                                            </div>
                                            <div class="form-group">
                                                <label>Cost (per unit)</label>
                                                <input type="number" name="cost" value="<?php echo $item['cost']; ?>" required min="0" step="0.01">
                                            </div>
                                            <div class="form-group">
                                                <input type="submit" name="update_item" class="btn" value="Update">
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    function showUpdateForm(itemId) {
        var form = document.getElementById('update-form-' + itemId);
        form.style.display = form.style.display === 'none' ? 'table-row' : 'none';
    }
    </script>
</body>
</html> 