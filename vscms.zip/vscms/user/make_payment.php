<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$message = "";
$payment_details = null;

// Handle payment submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["make_payment"])) {
    $service_id = trim($_POST["service_id"]);
    $amount = trim($_POST["amount"]);
    $payment_method = trim($_POST["payment_method"]);
    $transaction_id = "TRX" . uniqid();
    
    try {
        $conn->beginTransaction();
        
        // Insert payment record
        $sql = "INSERT INTO payments (service_id, amount, payment_method, transaction_id) 
                VALUES (:service_id, :amount, :payment_method, :transaction_id)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":service_id", $service_id, PDO::PARAM_INT);
        $stmt->bindParam(":amount", $amount, PDO::PARAM_STR);
        $stmt->bindParam(":payment_method", $payment_method, PDO::PARAM_STR);
        $stmt->bindParam(":transaction_id", $transaction_id, PDO::PARAM_STR);
        $stmt->execute();
        
        // Update service payment status
        $sql = "UPDATE services SET payment_status = 'paid' WHERE id = :service_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":service_id", $service_id, PDO::PARAM_INT);
        $stmt->execute();
        
        $conn->commit();
        
        // Get payment details for display
        $sql = "SELECT p.*, s.service_date, v.make, v.model, v.plate, m.name as mechanic_name
                FROM payments p 
                INNER JOIN services s ON p.service_id = s.id 
                INNER JOIN vehicles v ON s.vehicle_id = v.id 
                LEFT JOIN mechanics m ON s.mechanic_id = m.id
                WHERE p.transaction_id = :transaction_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(":transaction_id", $transaction_id, PDO::PARAM_STR);
        $stmt->execute();
        $payment_details = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $message = "Payment made successfully!";
    } catch (Exception $e) {
        $conn->rollBack();
        $message = "Error processing payment: " . $e->getMessage();
    }
}

// Get user's pending services
$sql = "SELECT s.*, v.make, v.model, v.plate, m.name as mechanic_name
        FROM services s 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        LEFT JOIN mechanics m ON s.mechanic_id = m.id
        WHERE s.customer_id = :customer_id 
        AND s.payment_status = 'pending'
        AND s.status = 'completed'
        ORDER BY s.service_date DESC";
$pending_services = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $pending_services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Get user's payment history
$sql = "SELECT p.*, s.service_date, v.make, v.model, v.plate, m.name as mechanic_name
        FROM payments p 
        INNER JOIN services s ON p.service_id = s.id 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        LEFT JOIN mechanics m ON s.mechanic_id = m.id
        WHERE s.customer_id = :customer_id 
        ORDER BY p.payment_date DESC";
$payments = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make Payment - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-pending {
            background-color: #f1c40f;
        }
        .badge-paid {
            background-color: #2ecc71;
        }
        .payment-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .payment-details {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .payment-details h3 {
            margin-top: 0;
            color: var(--primary-color);
        }
        .payment-details p {
            margin: 5px 0;
        }
        .payment-details strong {
            display: inline-block;
            width: 150px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="user_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <?php if ($payment_details): ?>
                <div class="payment-details">
                    <h3>Payment Receipt</h3>
                    <p><strong>Transaction ID:</strong> <?php echo htmlspecialchars($payment_details['transaction_id']); ?></p>
                    <p><strong>Date:</strong> <?php echo date('F j, Y g:i A', strtotime($payment_details['payment_date'])); ?></p>
                    <p><strong>Vehicle:</strong> <?php echo htmlspecialchars($payment_details['make'] . " " . $payment_details['model'] . " (" . $payment_details['plate'] . ")"); ?></p>
                    <p><strong>Mechanic:</strong> <?php echo htmlspecialchars($payment_details['mechanic_name'] ?? 'Not assigned'); ?></p>
                    <p><strong>Amount:</strong> $<?php echo number_format($payment_details['amount'], 2); ?></p>
                    <p><strong>Payment Method:</strong> <?php echo ucfirst(str_replace('_', ' ', $payment_details['payment_method'])); ?></p>
                </div>
            <?php endif; ?>

            <div class="card">
                <h2>Pending Payments</h2>
                <?php if (empty($pending_services)): ?>
                    <p>No pending payments found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Vehicle</th>
                                    <th>Mechanic</th>
                                    <th>Amount</th>
                                    <th>Make Payment</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pending_services as $service): ?>
                                    <tr>
                                        <td><?php echo isset($service['service_date']) ? date('F j, Y g:i A', strtotime($service['service_date'])) : 'N/A'; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars(($service['make'] ?? '') . " " . ($service['model'] ?? '')); ?><br>
                                            <small>Plate: <?php echo htmlspecialchars($service['plate'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['mechanic_name'] ?? 'Not assigned'); ?></td>
                                        <td>$<?php echo isset($service['amount']) ? number_format($service['amount'], 2) : '0.00'; ?></td>
                                        <td>
                                            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="payment-form">
                                                <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                <input type="hidden" name="amount" value="<?php echo $service['amount']; ?>">
                                                <div class="form-group">
                                                    <select name="payment_method" required>
                                                        <option value="">Select Method</option>
                                                        <option value="credit_card">Credit Card</option>
                                                        <option value="debit_card">Debit Card</option>
                                                        <option value="net_banking">Net Banking</option>
                                                        <option value="upi">UPI</option>
                                                    </select>
                                                </div>
                                                <input type="submit" name="make_payment" class="btn" value="Pay Now">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card">
                <h2>Payment History</h2>
                <?php if (empty($payments)): ?>
                    <p>No payment history found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Vehicle</th>
                                    <th>Mechanic</th>
                                    <th>Amount</th>
                                    <th>Payment Method</th>
                                    <th>Transaction ID</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payments as $payment): ?>
                                    <tr>
                                        <td><?php echo isset($payment['payment_date']) ? date('F j, Y g:i A', strtotime($payment['payment_date'])) : 'N/A'; ?></td>
                                        <td>
                                            <?php echo htmlspecialchars(($payment['make'] ?? '') . " " . ($payment['model'] ?? '')); ?><br>
                                            <small>Plate: <?php echo htmlspecialchars($payment['plate'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($payment['mechanic_name'] ?? 'Not assigned'); ?></td>
                                        <td>$<?php echo isset($payment['amount']) ? number_format($payment['amount'], 2) : '0.00'; ?></td>
                                        <td><?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?></td>
                                        <td><?php echo htmlspecialchars($payment['transaction_id']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 