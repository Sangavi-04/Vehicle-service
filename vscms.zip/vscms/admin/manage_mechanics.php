<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

$message = "";

// Handle mechanic addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_mechanic"])) {
    $name = trim($_POST["name"]);
    $phone = trim($_POST["phone"]);
    $expertise = trim($_POST["expertise"]);
    
    $sql = "INSERT INTO mechanics (name, phone, expertise) VALUES (:name, :phone, :expertise)";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":name", $name, PDO::PARAM_STR);
        $stmt->bindParam(":phone", $phone, PDO::PARAM_STR);
        $stmt->bindParam(":expertise", $expertise, PDO::PARAM_STR);
        
        if ($stmt->execute()) {
            $message = "Mechanic added successfully!";
        } else {
            $message = "Error adding mechanic. Please try again.";
        }
    }
}

// Get all mechanics
$sql = "SELECT * FROM mechanics ORDER BY id DESC";
$mechanics = [];
if($stmt = $conn->prepare($sql)){
    if($stmt->execute()){
        $mechanics = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Mechanics - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="card">
                <h2>Add New Mechanic</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label>Expertise</label>
                        <input type="text" name="expertise" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" name="add_mechanic" class="btn" value="Add Mechanic">
                    </div>
                </form>
            </div>

            <div class="card">
                <h2>Mechanic List</h2>
                <?php if (empty($mechanics)): ?>
                    <p>No mechanics found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Expertise</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($mechanics as $mechanic): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($mechanic['id']); ?></td>
                                        <td><?php echo htmlspecialchars($mechanic['name']); ?></td>
                                        <td><?php echo htmlspecialchars($mechanic['phone'] ?? 'Not provided'); ?></td>
                                        <td><?php echo htmlspecialchars($mechanic['expertise'] ?? 'Not specified'); ?></td>
                                        <td>
                                            <div class="action-buttons">
                                                <a href="view_mechanic.php?id=<?php echo $mechanic['id']; ?>" class="btn">View</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 