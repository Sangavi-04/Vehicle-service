<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build the query
$sql = "SELECT s.*, c.name as customer_name, v.make, v.model, v.plate, m.name as mechanic_name 
        FROM services s 
        LEFT JOIN customers c ON s.customer_id = c.id 
        LEFT JOIN vehicles v ON s.vehicle_id = v.id 
        LEFT JOIN mechanics m ON s.mechanic_id = m.id 
        WHERE 1=1";

$params = [];

if (!empty($status)) {
    $sql .= " AND s.status = :status";
    $params[':status'] = $status;
}

if (!empty($date_from)) {
    $sql .= " AND s.service_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if (!empty($date_to)) {
    $sql .= " AND s.service_date <= :date_to";
    $params[':date_to'] = $date_to;
}

$sql .= " ORDER BY s.service_date DESC";

$services = [];
if($stmt = $conn->prepare($sql)){
    foreach($params as $key => $value){
        $stmt->bindValue($key, $value);
    }
    if($stmt->execute()){
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service History - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .filter-form {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .filter-form .form-group {
            margin: 0;
            flex: 1;
            min-width: 200px;
        }
        .service-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .service-table th, .service-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .service-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .service-table tr:hover {
            background-color: #f5f5f5;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-pending { background-color: #f1c40f; }
        .badge-approved { background-color: #3498db; }
        .badge-in_progress { background-color: #2ecc71; }
        .badge-completed { background-color: #27ae60; }
        .badge-cancelled { background-color: #e74c3c; }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <div class="card">
                <h2>Service History</h2>
                
                <form method="get" class="filter-form">
                    <div class="form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">All Statuses</option>
                            <option value="pending" <?php echo $status == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="approved" <?php echo $status == 'approved' ? 'selected' : ''; ?>>Approved</option>
                            <option value="in_progress" <?php echo $status == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                            <option value="completed" <?php echo $status == 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $status == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Date From</label>
                        <input type="date" name="date_from" value="<?php echo $date_from; ?>">
                    </div>
                    <div class="form-group">
                        <label>Date To</label>
                        <input type="date" name="date_to" value="<?php echo $date_to; ?>">
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn" value="Filter">
                    </div>
                </form>

                <?php if (empty($services)): ?>
                    <p>No services found matching the criteria.</p>
                <?php else: ?>
                    <table class="service-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Customer</th>
                                <th>Vehicle</th>
                                <th>Mechanic</th>
                                <th>Status</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($services as $service): ?>
                                <tr>
                                    <td><?php echo date('F j, Y g:i A', strtotime($service['service_date'])); ?></td>
                                    <td><?php echo htmlspecialchars($service['customer_name']); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($service['make'] . " " . $service['model']); ?><br>
                                        <small>Plate: <?php echo htmlspecialchars($service['plate']); ?></small>
                                    </td>
                                    <td><?php echo $service['mechanic_name'] ? htmlspecialchars($service['mechanic_name']) : 'Not assigned'; ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $service['status']; ?>">
                                            <?php echo ucfirst($service['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($service['notes']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 