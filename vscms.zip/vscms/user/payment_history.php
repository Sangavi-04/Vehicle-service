<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

// Get payment history for the logged-in user
$sql = "SELECT p.*, s.service_date, v.make, v.model, v.plate 
        FROM payments p 
        INNER JOIN services s ON p.service_id = s.id 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        WHERE p.customer_id = :customer_id 
        ORDER BY p.payment_date DESC";

$payments = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":customer_id", $_SESSION["id"], PDO::PARAM_INT);
    if($stmt->execute()){
        $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment History - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .payment-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .payment-table th, .payment-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .payment-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .payment-table tr:hover {
            background-color: #f5f5f5;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-success { background-color: #2ecc71; }
        .badge-pending { background-color: #f1c40f; }
        .badge-failed { background-color: #e74c3c; }
        .stats-card {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-item {
            flex: 1;
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
        }
        .stat-item h3 {
            margin: 0 0 10px 0;
            color: var(--primary-color);
        }
        .stat-item p {
            font-size: 24px;
            margin: 0;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="user_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <div class="card">
                <h2>Payment History</h2>
                
                <?php if (empty($payments)): ?>
                    <p>No payment history found.</p>
                <?php else: ?>
                    <table class="payment-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Vehicle</th>
                                <th>Service Date</th>
                                <th>Amount</th>
                                <th>Payment Method</th>
                                <th>Transaction ID</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?php echo date('F j, Y g:i A', strtotime($payment['payment_date'])); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($payment['make'] . " " . $payment['model']); ?><br>
                                        <small>Plate: <?php echo htmlspecialchars($payment['plate']); ?></small>
                                    </td>
                                    <td><?php echo date('F j, Y', strtotime($payment['service_date'])); ?></td>
                                    <td>$<?php echo number_format($payment['amount'], 2); ?></td>
                                    <td><?php echo ucfirst(str_replace('_', ' ', $payment['payment_method'])); ?></td>
                                    <td><?php echo htmlspecialchars($payment['transaction_id']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $payment['status']; ?>">
                                            <?php echo ucfirst($payment['status']); ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 