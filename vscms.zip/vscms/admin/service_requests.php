<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

$message = "";

// Handle mechanic assignment
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["assign_mechanic"])) {
    $service_id = trim($_POST["service_id"]);
    $mechanic_id = trim($_POST["mechanic_id"]);
    
    $sql = "UPDATE services SET mechanic_id = :mechanic_id, status = 'in_progress' WHERE id = :service_id";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":mechanic_id", $mechanic_id, PDO::PARAM_INT);
        $stmt->bindParam(":service_id", $service_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $message = "Mechanic assigned successfully!";
        } else {
            $message = "Error assigning mechanic. Please try again.";
        }
    }
}

// Handle status update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update_status"])) {
    $service_id = trim($_POST["service_id"]);
    $status = trim($_POST["status"]);
    
    $sql = "UPDATE services SET status = :status WHERE id = :service_id";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bindParam(":status", $status, PDO::PARAM_STR);
        $stmt->bindParam(":service_id", $service_id, PDO::PARAM_INT);
        
        if ($stmt->execute()) {
            $message = "Service status updated successfully!";
        } else {
            $message = "Error updating status. Please try again.";
        }
    }
}

// Get all services with their status
$sql = "SELECT s.*, c.name as customer_name, v.make, v.model, v.plate, m.name as mechanic_name
        FROM services s 
        INNER JOIN customers c ON s.customer_id = c.id 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        LEFT JOIN mechanics m ON s.mechanic_id = m.id
        ORDER BY s.service_date DESC";
$services = [];
if($stmt = $conn->prepare($sql)){
    if($stmt->execute()){
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Get all mechanics
$sql = "SELECT * FROM mechanics ORDER BY name";
$mechanics = [];
if($stmt = $conn->prepare($sql)){
    if($stmt->execute()){
        $mechanics = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Requests - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-pending {
            background-color: #f1c40f;
        }
        .badge-in_progress {
            background-color: #3498db;
        }
        .badge-completed {
            background-color: #2ecc71;
        }
        .status-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="admin_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="alert alert-success"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="card">
                <h2>Service Requests</h2>
                <?php if (empty($services)): ?>
                    <p>No service requests found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Customer</th>
                                    <th>Vehicle</th>
                                    <th>Service Type</th>
                                    <th>Status</th>
                                    <th>Mechanic</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $service): ?>
                                    <tr>
                                        <td><?php echo isset($service['service_date']) ? date('F j, Y g:i A', strtotime($service['service_date'])) : 'N/A'; ?></td>
                                        <td><?php echo htmlspecialchars($service['customer_name']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars(($service['make'] ?? '') . " " . ($service['model'] ?? '')); ?><br>
                                            <small>Plate: <?php echo htmlspecialchars($service['plate'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['service_type'] ?? 'N/A'); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo $service['status']; ?>">
                                                <?php echo ucfirst(str_replace('_', ' ', $service['status'])); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['mechanic_name'] ?? 'Not assigned'); ?></td>
                                        <td>
                                            <?php if ($service['status'] === 'pending'): ?>
                                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="display: inline;">
                                                    <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                    <div class="form-group">
                                                        <select name="mechanic_id" required>
                                                            <option value="">Select Mechanic</option>
                                                            <?php foreach ($mechanics as $mechanic): ?>
                                                                <option value="<?php echo $mechanic['id']; ?>">
                                                                    <?php echo htmlspecialchars($mechanic['name']); ?> 
                                                                    (<?php echo htmlspecialchars($mechanic['expertise'] ?? 'Not specified'); ?>)
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <input type="submit" name="assign_mechanic" class="btn" value="Assign Mechanic">
                                                </form>
                                            <?php elseif ($service['status'] === 'in_progress'): ?>
                                                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="status-form">
                                                    <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>">
                                                    <div class="form-group">
                                                        <select name="status" required>
                                                            <option value="in_progress" selected>In Progress</option>
                                                            <option value="completed">Mark as Completed</option>
                                                        </select>
                                                    </div>
                                                    <input type="submit" name="update_status" class="btn" value="Update Status">
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 