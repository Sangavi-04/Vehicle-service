<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

$user_id = $_SESSION["user_id"];

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : '';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Build the query
$sql = "SELECT s.*, v.make, v.model, v.plate, m.name as mechanic_name 
        FROM services s 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        INNER JOIN mechanics m ON s.mechanic_id = m.id 
        WHERE s.customer_id = :customer_id";

$params = [":customer_id" => $user_id];

if (!empty($status)) {
    $sql .= " AND s.status = :status";
    $params[":status"] = $status;
}

if (!empty($start_date)) {
    $sql .= " AND s.service_date >= :start_date";
    $params[":start_date"] = $start_date;
}

if (!empty($end_date)) {
    $sql .= " AND s.service_date <= :end_date";
    $params[":end_date"] = $end_date;
}

$sql .= " ORDER BY s.service_date DESC";

// Execute the query
$services = [];
if($stmt = $conn->prepare($sql)){
    foreach($params as $key => $value){
        $stmt->bindValue($key, $value);
    }
    if($stmt->execute()){
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service History - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .filter-form {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .filter-group select, .filter-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .service-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .service-table th, .service-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .service-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .service-table tr:hover {
            background-color: #f5f5f5;
        }
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-pending { background-color: #f1c40f; }
        .badge-in-progress { background-color: #3498db; }
        .badge-completed { background-color: #2ecc71; }
        .badge-cancelled { background-color: #e74c3c; }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="user_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <div class="card">
                <h2>Service History</h2>
                
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="get" class="filter-form">
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo $status == 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="in_progress" <?php echo $status == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                            <option value="completed" <?php echo $status == 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="cancelled" <?php echo $status == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Start Date</label>
                        <input type="date" name="start_date" value="<?php echo $start_date; ?>">
                    </div>
                    <div class="filter-group">
                        <label>End Date</label>
                        <input type="date" name="end_date" value="<?php echo $end_date; ?>">
                    </div>
                    <div class="filter-group" style="align-self: flex-end;">
                        <button type="submit" class="btn">Filter</button>
                    </div>
                </form>

                <?php if (empty($services)): ?>
                    <p>No service history found.</p>
                <?php else: ?>
                    <table class="service-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Vehicle</th>
                                <th>Mechanic</th>
                                <th>Status</th>
                                <th>Payment Status</th>
                                <th>Amount</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($services as $service): ?>
                                <tr>
                                    <td><?php echo date('F j, Y g:i A', strtotime($service['service_date'])); ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($service['make'] . " " . $service['model']); ?><br>
                                        <small>Plate: <?php echo htmlspecialchars($service['plate']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($service['mechanic_name']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo str_replace('_', '-', $service['status']); ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $service['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $service['payment_status'] == 'paid' ? 'completed' : 'pending'; ?>">
                                            <?php echo ucfirst($service['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td>$<?php echo number_format($service['amount'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($service['notes']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 