<?php
require_once '../includes/db_connection.php';

// Check if user is logged in
if(!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true){
    header("location: user_login.php");
    exit;
}

$user_id = $_SESSION["user_id"];

// Get active services
$sql = "SELECT s.*, v.make, v.model, v.plate, m.name as mechanic_name 
        FROM services s 
        LEFT JOIN vehicles v ON s.vehicle_id = v.id 
        LEFT JOIN mechanics m ON s.mechanic_id = m.id 
        WHERE s.customer_id = :customer_id 
        AND s.status != 'completed' AND s.status != 'cancelled' 
        ORDER BY s.service_date DESC";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bindParam(":customer_id", $user_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        $active_services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    unset($stmt);
}

// Function to get status badge class
function getStatusBadgeClass($status) {
    switch($status) {
        case 'pending':
            return 'badge-warning';
        case 'approved':
            return 'badge-info';
        case 'in_progress':
            return 'badge-primary';
        default:
            return 'badge-secondary';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Track Progress - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .badge {
            padding: 5px 10px;
            border-radius: 15px;
            color: white;
            font-size: 0.9em;
        }
        .badge-warning { background-color: #f1c40f; }
        .badge-info { background-color: #3498db; }
        .badge-primary { background-color: #2ecc71; }
        .badge-secondary { background-color: #95a5a6; }
        
        .service-card {
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 5px;
            background-color: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .service-details {
            margin-top: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="user_dashboard.php" class="btn">Back to Dashboard</a>
            </div>

            <div class="card">
                <h2>Active Services</h2>
                <?php if (empty($active_services)): ?>
                    <p>No active services found.</p>
                <?php else: ?>
                    <?php foreach ($active_services as $service): ?>
                        <div class="service-card">
                            <h3>
                                <?php echo htmlspecialchars($service['make'] . " " . $service['model']); ?>
                                <span class="badge <?php echo getStatusBadgeClass($service['status']); ?>">
                                    <?php echo ucfirst($service['status']); ?>
                                </span>
                            </h3>
                            <div class="service-details">
                                <p><strong>License Plate:</strong> <?php echo htmlspecialchars($service['plate']); ?></p>
                                <p><strong>Service Date:</strong> <?php echo date('F j, Y g:i A', strtotime($service['service_date'])); ?></p>
                                <p><strong>Mechanic:</strong> <?php echo $service['mechanic_name'] ? htmlspecialchars($service['mechanic_name']) : 'Not assigned yet'; ?></p>
                                <p><strong>Notes:</strong> <?php echo htmlspecialchars($service['notes']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 