<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}

// Get mechanic ID from URL
$mechanic_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if($mechanic_id <= 0) {
    header("location: manage_mechanics.php");
    exit;
}

// Get mechanic details
$sql = "SELECT * FROM mechanics WHERE id = :id";
$mechanic = null;
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":id", $mechanic_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $mechanic = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

if(!$mechanic) {
    header("location: manage_mechanics.php");
    exit;
}

// Get mechanic's services
$sql = "SELECT s.*, v.make, v.model, v.plate, c.name as customer_name 
        FROM services s 
        INNER JOIN vehicles v ON s.vehicle_id = v.id 
        INNER JOIN customers c ON s.customer_id = c.id 
        WHERE s.mechanic_id = :mechanic_id 
        ORDER BY s.service_date DESC";
$services = [];
if($stmt = $conn->prepare($sql)){
    $stmt->bindParam(":mechanic_id", $mechanic_id, PDO::PARAM_INT);
    if($stmt->execute()){
        $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Mechanic - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-container {
            padding: 20px;
        }
        .card {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px var(--shadow-color);
            margin-bottom: 20px;
        }
        .mechanic-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .info-item {
            padding: 15px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .info-item h3 {
            margin: 0 0 10px 0;
            color: var(--primary-color);
        }
        .info-item p {
            margin: 0;
        }
        .table-container {
            overflow-x: auto;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .data-table th, .data-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .data-table th {
            background-color: var(--primary-color);
            color: white;
        }
        .data-table tr:hover {
            background-color: #f5f5f5;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--primary-color-dark);
        }
        .btn-secondary {
            background: #6c757d;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="manage_mechanics.php" class="btn btn-secondary">Back to Mechanics</a>
            </div>

            <div class="card">
                <h2>Mechanic Details</h2>
                <div class="mechanic-info">
                    <div class="info-item">
                        <h3>Personal Information</h3>
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($mechanic['name']); ?></p>
                        <p><strong>Phone:</strong> <?php echo htmlspecialchars($mechanic['phone'] ?? 'Not provided'); ?></p>
                        <p><strong>Expertise:</strong> <?php echo htmlspecialchars($mechanic['expertise'] ?? 'Not specified'); ?></p>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2>Service History</h2>
                <?php if (empty($services)): ?>
                    <p>No service history found.</p>
                <?php else: ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Customer</th>
                                    <th>Vehicle</th>
                                    <th>Service Type</th>
                                    <th>Amount</th>
                                    <th>Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($services as $service): ?>
                                    <tr>
                                        <td><?php echo isset($service['service_date']) ? date('F j, Y g:i A', strtotime($service['service_date'])) : 'N/A'; ?></td>
                                        <td><?php echo htmlspecialchars($service['customer_name']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars(($service['make'] ?? '') . " " . ($service['model'] ?? '')); ?><br>
                                            <small>Plate: <?php echo htmlspecialchars($service['plate'] ?? 'N/A'); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($service['service_type'] ?? 'N/A'); ?></td>
                                        <td>$<?php echo isset($service['amount']) ? number_format($service['amount'], 2) : '0.00'; ?></td>
                                        <td><?php echo htmlspecialchars($service['notes'] ?? 'No notes'); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html> 