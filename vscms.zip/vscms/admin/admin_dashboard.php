<?php
require_once '../includes/db_connection.php';

// Check if admin is logged in
if(!isset($_SESSION["admin_loggedin"]) || $_SESSION["admin_loggedin"] !== true){
    header("location: admin_login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - VSCMS</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div style="text-align: right; margin-bottom: 20px;">
                <a href="logout.php" class="btn" style="background: #d32f2f;">Logout</a>
            </div>
            <div class="dashboard">
                <div class="card">
                    <h3>Manage Users</h3>
                    <p>View, add, edit, and delete customer accounts</p>
                    <a href="manage_users.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Manage Mechanics</h3>
                    <p>Add or assign mechanics to services</p>
                    <a href="manage_mechanics.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Service Requests</h3>
                    <p>View, approve, and assign services</p>
                    <a href="service_requests.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Inventory Management</h3>
                    <p>Track and update parts/tools inventory</p>
                    <a href="inventory.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Service History</h3>
                    <p>Search service records by customer or vehicle</p>
                    <a href="service_history.php" class="btn">Access</a>
                </div>

                <div class="card">
                    <h3>Transactions</h3>
                    <p>View completed service transactions</p>
                    <a href="transactions.php" class="btn">Access</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 